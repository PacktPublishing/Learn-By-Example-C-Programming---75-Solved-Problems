#include <iostream>
#include <string>
using namespace std;

int main()
{
  string firstName("Vitthal");
  string lastName = "Srinivasan";
  string fullName = firstName + lastName;

  cout << "First name = " << firstName << endl;
  cout << "Last name = " << lastName << endl;
  cout << "Full name = " << fullName << endl;



}

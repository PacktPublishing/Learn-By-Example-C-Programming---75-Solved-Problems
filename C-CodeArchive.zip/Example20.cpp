#include <iostream>
#include <string>
using namespace std;


int main()
{

  int x = 5;
  const int& y = 5;

  cout << "x = " << x << " y = " << y << endl;

}

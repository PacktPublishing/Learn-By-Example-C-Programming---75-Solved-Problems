#include <iostream>
#include <string>
using namespace std;


int main()
{

  int y = 5;
  const int& x;
  x = 5;

  cout << "x = " << x << " y = " << y << endl;

}
